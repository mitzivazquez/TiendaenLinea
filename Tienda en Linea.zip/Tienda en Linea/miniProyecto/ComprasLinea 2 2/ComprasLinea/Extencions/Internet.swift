//
//  Internet.swift
//  ComprasLinea
//
//  Created by Natanael Cruz Mota on 17/01/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import Foundation


public class Internet {
  class func Fallo () -> Bool {
      var direccion = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0),sin_zero: (0,0,0,0,0,0,0,0))
      direccion.sin_len = UInt8(MemoryLayout.size(ofValue: direccion))
      direccion.sin_family = sa_family_t(AF_INET)
      
       let defaultRouteReachability = withUnsafePointer(to: &direccion){
          $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
              direccion in SCNetworkReachabilityCreateWithAddress(nil, direccion)
              
          }
      }
      
      var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
      if SCNetwork == false {
          return false
      }
      let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
      let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
      let ret = (isReachable && !needsConnection)
  
        return ret
      }
}
