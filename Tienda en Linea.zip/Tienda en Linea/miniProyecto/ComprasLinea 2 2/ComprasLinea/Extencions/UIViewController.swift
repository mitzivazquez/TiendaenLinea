//
//  UIVIewComtroller.swift
//  ComprasLinea
//
//  Created by iOS Developer on 1/14/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit
import CryptoKit

 //MARK: -PUBLIC VARIABLES
var container: UIView = UIView()
var loadingView: UIView = UIView()
var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()

extension UIViewController{
    //MARK: - FUNCTION ACTIVITY INDICATOR
    func showActivityIndicatory(uiView: UIView) {
          container.frame = uiView.frame
          container.center = uiView.center
       container.backgroundColor = UIColor.clear

       loadingView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
          loadingView.center = uiView.center
       loadingView.backgroundColor = UIColor(displayP3Red: (235/255), green: (236/255), blue: (240/255), alpha: 0.6)
          loadingView.clipsToBounds = true
          loadingView.layer.cornerRadius = 10
          
       activityIndicator.style = UIActivityIndicatorView.Style.large
          activityIndicator.frame = CGRect(x: 0.0, y: 0.0, width: 40.0, height: 40.0);
          activityIndicator.center = CGPoint(x: loadingView.frame.size.width / 2,
                                  y: loadingView.frame.size.height / 2);
       activityIndicator.color = UIColor.darkGray
          
          loadingView.addSubview(activityIndicator)
          container.addSubview(loadingView)
          uiView.addSubview(container)
          activityIndicator.startAnimating()
      }
      
      // Oculta el indicador de actividades
      func hideActivityIndicator(uiView: UIView) {
          activityIndicator.stopAnimating()
          container.removeFromSuperview()
      }

    //MARK: -FUNCTION ALERTS
     func basica (title:String, message:String){
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
      func accion (title:String, message:String, actionButton: @escaping () -> ()){
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in
                DispatchQueue.main.async {
                    actionButton()
                }
            }))
            self.present(alert, animated: true, completion: nil)
        }
    //MARK: -FUNCTION CONVERT BASE64 AND CONVERT IMAGE
    func ConvertBase64StringToImage (imageBase64String:String) -> UIImage {
          let imageData = Data.init(base64Encoded: imageBase64String, options: .init(rawValue: 1))
          let image = UIImage(data: imageData!)
          return image!
      }
    func ConvertImageToBase64String (img: UIImage) -> String {
          return img.jpegData(compressionQuality: 1)?.base64EncodedString() ?? ""
      }
    //MARK: -FUNCTION CIFRADO
     func cifrarPassword(contrasena:String) -> String{
         let password = Data(contrasena.utf8)
         let has = SHA256.hash(data: password)
         return has.compactMap { String(format: "%02x", $0) }.joined()
    }
     //MARK: -FUNCTION HIDEKEYBOARD
    func hideKeyboard(){
        let tap:UITapGestureRecognizer = UITapGestureRecognizer (
            target: self, action: #selector(self.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard(){
        view.endEditing(true)
    }
    
}
