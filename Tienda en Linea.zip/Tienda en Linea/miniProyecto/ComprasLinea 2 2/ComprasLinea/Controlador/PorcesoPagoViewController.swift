//
//  PorcesoPagoViewController.swift
//  ComprasLinea
//
//  Created by MAC on 12/22/19.
//  Copyright © 2019 MAC. All rights reserved.
//

import UIKit

class PorcesoPagoViewController: UIViewController {
    
    //MARK:-IBOUTLETS
    @IBOutlet weak var lblFolio: UILabel!
    @IBOutlet weak var lblCorreo: UILabel!
    @IBOutlet weak var lblTarjeta: UILabel!
    @IBOutlet weak var lblDireccion: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    @IBOutlet weak var tablaHistorial: UITableView!
    
    
    //MARK:-PUBLIC VARIABLES
    var delegate:stackUpdateProtocol!
    var folio: String = ""
    var correo: String = ""
    var compraCarrito:Array<Dictionary<String, Any>> = []
    var objProductosSeleccionados = [ProductoSeleccionado]()
    var total: Double = 0.0
    var domicilio: String = ""
    var tarjeta: String = ""
    var subtotal: String = ""
    
    //MARK:-LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.tablaHistorial.delegate = self
        self.tablaHistorial.dataSource = self
        
        for pro in objProductosSeleccionados{
         let d:[String: Any] = ["nombreProducto": pro.producto.nombreProducto,"cantidadComprada": pro.cantidadCompra,"subtotal": pro.subtotal]
                  compraCarrito.append(d)
              }
        lblCorreo.text = correo
        lblFolio.text = folio
        lblTotal.text = String(total)
        lblTarjeta.text = tarjeta
        lblDireccion.text = domicilio
    
    }
    //MARK:-IBACTIONS
    @IBAction func btnFinalizar(_ sender: Any) {
        guard let correo = lblCorreo.text, let total = lblTotal.text, let folio = lblFolio.text else {return}
        self.correo = correo
        self.total = Double(total) as! Double
        self.folio = folio
        
        let vcIndex = self.navigationController?.viewControllers.firstIndex(where: { (viewController) -> Bool in

            if let _ = viewController as? ProductoViewController {
                return true
            }
            return false
        })

        let vcProducto = self.navigationController?.viewControllers[vcIndex!] as! ProductoViewController
        self.delegate = vcProducto
        delegate.actualizaStack()
        self.navigationController?.popToViewController(vcProducto, animated: true)
        
        }
    
    func mostrarProductos(){
            let story = UIStoryboard(name: "Main", bundle: nil)
            let control = story.instantiateViewController(identifier: "producto") as! ProductoViewController
            control.correo = correo
            self.present(control,animated: true)
           }
}
//MARK:-EXTENSION
extension PorcesoPagoViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objProductosSeleccionados.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCellHistorial
        
        let productoSeleccionado = objProductosSeleccionados[indexPath.row]
        
        cell.lblNombreProducto.text = String(productoSeleccionado.producto.nombreProducto)
        cell.lblCantidad.text = String(productoSeleccionado.cantidadCompra)
        return cell
    }
    
    
}

protocol stackUpdateProtocol {
    func actualizaStack()
}
