//
//  ProductoViewController.swift
//  ComprasLinea
//
//  Created by MAC on 12/19/19.
//  Copyright © 2019 MAC. All rights reserved.
//

import UIKit
import CoreData

class ProductoViewController: UIViewController {

    //MARK: -IBOUTLETS
    @IBOutlet weak var tablaProductos: UITableView!

    //MARK: -PUBLIC VARIABLES
    var productos: Array<Product> = []
    var arrProductosSeleccionados: Array<ProductoSeleccionado> = []
    var lista:[NSManagedObject] = []
    var bandera: Bool = true
    var correo: String = ""
    var subtotal: String = ""
    var bNeedToUpdate:Bool = false

    //MARK: -LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        tablaProductos.delegate = self
        tablaProductos.dataSource = self
        self.tablaProductos.reloadData()
        bNeedToUpdate = true
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.setHidesBackButton(true, animated: false)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if(bNeedToUpdate){
            mostrarProductos()
        }
    }
    
        //MARK: -IBACTIONS
    @IBAction func btnComprar(_ sender: UIButton) {
        performSegue(withIdentifier: "carrito", sender: nil)
    }

    @IBAction func closeSessionTapped(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popToRootViewController(animated: true)
        
    }
    
    //MARK: -NAVIGATION
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! CarritoViewController
        destination.objProductosSeleccionados = arrProductosSeleccionados
        destination.correo = correo
        destination.subtotal = subtotal
    }
    func mostrarProductos(){
        self.showActivityIndicatory(uiView: self.view)
        Producto(correo: correo,completions: { listaproducto in self.productos = listaproducto
        DispatchQueue.main.async {
         self.hideActivityIndicator(uiView: self.view)
         self.tablaProductos.reloadData()
            self.bNeedToUpdate = false
       }
    })
  }
}

 //MARK: -EXTENSIONS
extension ProductoViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("Tienes \(self.productos.count)")
        return self.productos.count
    }
  
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! TableViewCellProducto
        let product = productos[indexPath.row]
        let imgProducto = ConvertBase64StringToImage(imageBase64String: product.img)
        cell.lblProducto.text = (product.nombreProducto)
        cell.lblPrecio.text = String(product.precio)
        cell.lblStock.text = String(product.stock)
        cell.btnAgregar.isHidden =  product.stock == 0 ? true : false
        cell.imgProducto.image = imgProducto
        cell.producto = product
        cell.delegate = self
        
        let cont = Int(product.stock)
        if cont == 0 {
            cell.StpContador.isHidden = true
            cell.backgroundColor = UIColor(displayP3Red: 1.0, green: 0.0, blue: 0.0, alpha: 0.1)
            cell.lblCantidad.text = "0"
        }else{
            cell.StpContador.isHidden = false
            cell.backgroundColor = .clear
            cell.lblCantidad.text = "1"
        }
         return cell
    }
    
        
    func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        false
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 155
    }
    func guardarProducto(producto: String,precio: Float?,cantidad: Int16?) {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appDelegate.persistentContainer.viewContext
         let entity = NSEntityDescription.entity(forEntityName: "Compra", in: managedContext)!
         let managedObject = NSManagedObject(entity: entity, insertInto: managedContext)
         print(producto)
         managedObject.setValue(producto, forKeyPath: "nombreProducto")
         managedObject.setValue(precio, forKeyPath: "precio")
         managedObject.setValue(cantidad, forKeyPath: "cantidad")
         do{
             try managedContext.save()
            lista.append(managedObject)
         }catch let error as NSError {
             print("\(error.userInfo)")
     }
    }
}

extension ProductoViewController: Celda {
    func agregar(producto: Product, lbl:UILabel) {
        guard let cantidad = Int(lbl.text!) else {return}
        let results = arrProductosSeleccionados.filter { $0.producto.descripcion == producto.descripcion }
        if results.isEmpty{
            self.arrProductosSeleccionados.append(ProductoSeleccionado(iCantidad:cantidad, objProducto: producto, subtotal: Double(subtotal) ?? 0.0))
            self.basica(title: "Atencion", message: "Agrego un producto a su carrito")
        }else{
            guard let index = arrProductosSeleccionados.firstIndex(where: {$0.producto.descripcion == producto.descripcion }) else {return}
            arrProductosSeleccionados[index].cantidadCompra = cantidad
            self.basica(title: "Atencion", message: "Agrego un producto al carrito")
        }
        return
        
        /*NO TOCAR*/
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let managedContext = appDelegate!.persistentContainer.viewContext
        let fetchrequest = NSFetchRequest<NSManagedObject>(entityName: "Compra")
        
       do{
        
            let compra = try managedContext.fetch(fetchrequest)
            for datos in compra {
                self.lista.append(datos)
            }
            
        }catch let error as NSError{
            print("\(error.userInfo)")
        }
        
        
        
        var bandera = 1
       // var p = lista[0]
        for nombre in lista {
            
            if nombre.value(forKey: "nombreProducto") as? String == producto.nombreProducto {
                let aux:Int16 = (nombre.value(forKey: "cantidad") as? Int16)!
                guard let aux1:Int16 = Int16(lbl.text!) else {return}
                print("Cantidad1:\(aux)\(aux1)")
                let result = (aux + aux1)
                nombre.setValue(result, forKey: "cantidad")
                bandera = 0
                basica(title: "Atencion", message: "Agrego un producto al carrito")
            
                    do{
                    try managedContext.save()
                    
                }catch let error as NSError{
                    print("\(error.userInfo)")
                }
            }
            
        }
        
        if bandera == 1 {
            
            print("Nombre: \(producto.nombreProducto)")
            self.guardarProducto(producto: producto.nombreProducto, precio: producto.precio, cantidad: Int16(lbl.text!)!)
            basica(title: "Atencion", message: "Agrego un producto al carrito")
        }
    }
}


extension ProductoViewController: stackUpdateProtocol{
    
    func actualizaStack() {
        bNeedToUpdate =  true
    }
}
