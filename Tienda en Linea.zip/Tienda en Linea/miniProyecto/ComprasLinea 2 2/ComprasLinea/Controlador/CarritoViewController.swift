//
//  CarritoViewController.swift
//  ComprasLinea
//
//  Created by MAC on 12/20/19.
//  Copyright © 2019 MAC. All rights reserved.
//

import UIKit
import CoreData

class CarritoViewController: UIViewController {
    
    //MARK: -IBOUTLET
    @IBOutlet weak var lblTotal: UILabel!
    @IBOutlet weak var tablaComprar: UITableView!
    
    //MARK: -PUBLIC VARIABLES
    var total: Double = 0.0
    var objProductosSeleccionados = [ProductoSeleccionado]()
    var compra:[NSManagedObject] = []
    var correo:String = ""
    var compraCarrito:Array<Dictionary<String, Any>> = []
    var subtotal:String = ""
    var folio: String = ""
    
    //MARK: -LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tablaComprar.delegate = self
        self.tablaComprar.dataSource = self
        for p in objProductosSeleccionados{
                  let d:[String: Any] = ["nombreProducto": p.producto.nombreProducto,"cantidadComprada": p.cantidadCompra,"subtotal": p.subtotal]
                  compraCarrito.append(d)
              }
        
        /*let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let managedContext = appDelegate!.persistentContainer.viewContext
        
        let fetchrequest = NSFetchRequest<NSManagedObject>(entityName: "Compra") //trbajar sobre esta entidad, condicion que se quiere buscar
        do{
            let compra1 = try managedContext.fetch(fetchrequest)
            for datos in compra1 {
                self.compra.append(datos)
            }
            
        }catch let error as NSError{
            print("\(error.userInfo)")
        }*/
    }
   //MARK: -IBACTIONS
    @IBAction func btnGuardarCompra(_ sender: Any) {
        guard let total = lblTotal.text else {return}
        carritoCompras(carrito: compraCarrito, total: total, completions: { success, message, folio  in
            print("message completions -> \(message)")
            DispatchQueue.main.async {
            
            self.hideActivityIndicator(uiView: self.view)
            if success {
                self.folio = folio
                print(self.folio)
                self.accion(title: "Usuario", message: "Para culminar su compra ingrese su domicilio y datos de tarjeta" , actionButton: {
                    self.performSegue(withIdentifier: "domicilio", sender: nil)
            })
        } else {
                self.basica(title: "Atención", message: message)
                }
            }
        })
    }
    
    //MARK: -NAVIGATIONS
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! DomicilioViewController
        destination.correo = correo
        destination.objProductosSeleccionados = objProductosSeleccionados
        destination.total = total
        destination.folio = self.folio
        destination.subtotal = subtotal
    }
}

  //MARK: -EXTENSION
extension CarritoViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return objProductosSeleccionados.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
    let cell = tableView.dequeueReusableCell(withIdentifier: "producto", for: indexPath) as! TableViewCellCompra
    let productoSeleccionado = objProductosSeleccionados[indexPath.row]
    let imgProducto = ConvertBase64StringToImage(imageBase64String: productoSeleccionado.producto.img)
        cell.lblCantidad.text = String(productoSeleccionado.cantidadCompra)
        cell.lblProducto.text = productoSeleccionado.producto.nombreProducto
        cell.lblPrecio.text = String(productoSeleccionado.producto.precio)
        cell.imgProductoCompra.image = imgProducto
   var calcular = Double(cell.lblSubtotal.text!)
   let cantidad = Int16(cell.lblCantidad.text!)!
        print(cantidad)
   let precio = Double(cell.lblPrecio.text!)!
        print(precio * Double(cantidad))
        calcular = (precio * Double(cantidad))
        cell.lblSubtotal.text = "Subtotal $ \(String(describing: calcular!))"
        total += calcular!
        lblTotal.text = "Total a Pagar  $\(total)"
        subtotal = cell.lblSubtotal.text!
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {

                
                self.objProductosSeleccionados.remove(at: indexPath.row)
                self.total = 0.0
                 DispatchQueue.main.async {
                  self.tablaComprar.reloadData()
                }
            
        
            //self.objProductosSeleccionados.remove(at: indexPath.row)
            /*let objcore = compra[indexPath.row]
            let appDelegate = UIApplication.shared.delegate as? AppDelegate
            let managedContext = appDelegate!.persistentContainer.viewContext
             managedContext.delete(objcore) // elimina del coredata
             compra.remove(at: indexPath.row) // lo elimina del arreglo*/
       tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {}
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 160
        }
  }
}
