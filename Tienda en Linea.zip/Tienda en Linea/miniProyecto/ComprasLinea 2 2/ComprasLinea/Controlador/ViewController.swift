//
//  ViewController.swift
//  ComprasLinea
//
//  Created Vazquez Laparra Mitzi Zuleica by MAC on 12/18/19.
//  Copyright © 2019 MAC. All rights reserved.
//

import UIKit
import LocalAuthentication
import CryptoKit
import CoreData

class ViewController: UIViewController {
    
   //MARK: -IBOUTLETS
    @IBOutlet weak var txtUsuario: UITextField!
    @IBOutlet weak var txtContrasena: UITextField!
    @IBOutlet weak var btnBiometricos: UIButton!
    
    //MARK: -PUBLIC VARIABLES AND CONSTANTS
    var compra:[NSManagedObject] = []
    let context = LAContext() // la parte biometrica es la que se encarga de registrar en el sistema operativo
    var managedObject:NSManagedObject?
    var managedObjectBiometricos: NSManagedObject?
    var error: NSError?
    var strAlertMessage = String()
    

    //MARK: -LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboard()
        setupInterface()
        checkBiometric()
}
    
    
    
    //MARK: -IBACTIONS
    
    @IBAction func btnIdentificar(_ sender: UIButton) {
        if context.canEvaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, error: &error) {
                context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,localizedReason: self.strAlertMessage,reply: { [unowned self] (success, error) -> Void in
                                        
                DispatchQueue.main.async {
                if (success){
                print("Identificado Correctamente")
                //aqui va la vista a la que se desea ir
                guard let correo = self.managedObjectBiometricos?.value(forKey: "correo"),let password = self.managedObjectBiometricos?.value(forKey: "password") else {return}
                    self.Iniciar(usuario: correo as! String, contraseña: password as! String)
                } else  {
                    self.basica(title: "Error", message: "No identificado")
                                                
                if let error = error {
                                                     
                let strMessage = self.errorMessage(errorCode: error._code)
                self.notifyUser("Error", error: strMessage)
               }
             }
           }
         })
       }
    }

    @IBAction func btnRegistrar(_ sender: UIButton) {
       let story = UIStoryboard(name: "Main", bundle: nil)
        let control = story.instantiateViewController(identifier: "registro") as! RegistroViewController
         self.navigationController?.pushViewController(control, animated: true)
    }
    
    @IBAction func bntEntrar(_ sender: UIButton) {
        guard let usuario = self.txtUsuario.text, let contraseña = self.txtContrasena.text else {return}
            Iniciar (usuario: usuario, contraseña: contraseña)
        }
     
    //MARK: -NAVIGATIONS
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! ProductoViewController
       guard let usuario = self.txtUsuario.text else {return}
        destination.correo = usuario
        self.navigationController?.pushViewController(destination, animated: true)
    }
    
    //MARK: -FUNCTIONS
    private func setupInterface(){
        txtUsuario.text = "mitzi@gmail.com"//""
        txtContrasena.text = "12345678"//""
    }
    
    private func checkBiometric(){
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let managedContext = appDelegate!.persistentContainer.viewContext
        let fetchrequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Usuarios")
        fetchrequest.returnsObjectsAsFaults = false
        do {
                let result = try managedContext.fetch(fetchrequest)
                for datos in result as! [NSManagedObject]{
                        self.managedObjectBiometricos = datos
                        btnBiometricos.isEnabled = true
                if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error){
                 switch context.biometryType {
                  case .faceID:
                    btnBiometricos.setImage(UIImage(named: "facial"), for: UIControl.State.normal)
                      self.strAlertMessage = "Desea identificarse con FaceID?"
                       break
                  case .touchID:
                     btnBiometricos.setImage(UIImage(named: "huella"), for: UIControl.State.normal)
                     self.strAlertMessage = "Desea identificarse con TouchID?"
                        break
                  case .none:
                    print("No biometric sensor")
                 break
                 default:
                   print("Other")
                    }
               }else{
                if let err = error {
                let strMessager = self.errorMessage(errorCode: err._code)
                self.notifyUser("Error", error: strMessager)
           }
         }
     }
    }catch {
        print("Falló")
     }
    }
    
    func errorMessage(errorCode:Int) -> String{
         
            var strMessage = ""
            switch errorCode {
            case LAError.authenticationFailed.rawValue:
                
                strMessage = "Authentication Failed"
                
                break
            case LAError.userCancel.rawValue:
                
                strMessage = "User Cancel"
                
                break
            case LAError.userFallback.rawValue:
                
                strMessage = "User Fallback"
                
            case LAError.systemCancel.rawValue:
                
                strMessage = "System Cancel"
                
                break
            case LAError.passcodeNotSet.rawValue:
                
                strMessage = "Passcode Not set "
                break
            case LAError.biometryNotAvailable.rawValue:
                
                strMessage = "TouchID not Available"
                
                break
            case LAError.appCancel.rawValue:
                
                strMessage = "appCancel"
                
                break
            case LAError.biometryLockout.rawValue:
                
                strMessage = "Lockout"
                
                break
            default:
                
                strMessage = ""
            
            }
            return strMessage
        }
    
    func notifyUser(_ msg:String, error:String?){
        let alert = UIAlertController(title: msg, message: error, preferredStyle: .alert)
        let cancel = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
    }
    
    func iniciarBio(usuario: String,contraseña: String){
     if validar(usuario: usuario, contrasena: contraseña) {
            let ingresa: Ingresar = Ingresar(dic: ["correo": usuario, "password": self.cifrarPassword(contrasena: contraseña)])
                self.showActivityIndicatory(uiView: self.view)
                iniciarSesion(ingresar: ingresa, completions: { success, message  in
                    print("message completions -> \(message)")
                DispatchQueue.main.async {
                self.hideActivityIndicator(uiView: self.view)
            if success {
                 self.accion(title: "Usuario", message: message , actionButton: {
                 let story = UIStoryboard(name: "Main", bundle: nil)
                 let control = story.instantiateViewController(identifier: "productos") as! ProductoViewController
                guard let usuario = self.txtUsuario.text else {return}
                control.correo = usuario
                self.navigationController?.pushViewController(control, animated: true) //unwind segue
                 })
         } else {
            
             self.basica(title: "Atención", message: message)
          }
         }
       })
     }
     
     }
    
    func Iniciar (usuario:String, contraseña: String){
        if validar(usuario: usuario, contrasena: contraseña) {
        let ingresa: Ingresar = Ingresar(dic: ["correo": usuario, "password": self.cifrarPassword(contrasena: contraseña)])
            self.showActivityIndicatory(uiView: self.view)
            iniciarSesion(ingresar: ingresa, completions: { success, message  in
                print("message completions -> \(message)")
            DispatchQueue.main.async {
            self.hideActivityIndicator(uiView: self.view)
          if success {
    
            self.accion(title: "Usuario", message: message , actionButton: {
             let story = UIStoryboard(name: "Main", bundle: nil)
             let control = story.instantiateViewController(identifier: "producto") as! ProductoViewController
            guard let usuario = self.txtUsuario.text else {return}
            control.correo = usuario
            self.navigationController?.pushViewController(control, animated: true)
            })
                    
     } else {
        
         self.basica(title: "Atención", message: message)
      }
     }
   })
 }
}
    
       func guardarUsuario(correo: String, password: String){
          
          let appDelegate = UIApplication.shared.delegate as? AppDelegate
          let managedContext = appDelegate!.persistentContainer.viewContext
          let entity = NSEntityDescription.entity(forEntityName: "Usuarios", in: managedContext)!
          let managedObject = NSManagedObject(entity: entity, insertInto: managedContext)
          
          
          managedObject.setValue(correo, forKeyPath: "correo")
          managedObject.setValue(password, forKeyPath: "password")

          do{
              try managedContext.save()

          }catch let error as NSError {
              print("\(error.userInfo)")
          }
        self.actUsuario()
          
      }
    
       func actUsuario(){
           let appDelegate = UIApplication.shared.delegate as? AppDelegate
           let managedContext = appDelegate!.persistentContainer.viewContext
           let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Usuarios")
           request.returnsObjectsAsFaults = false
           
          do{
            let result = try managedContext.fetch(request)
           for usuario in result as! [NSManagedObject] {
               self.managedObject = usuario
           }
                 }catch let error as NSError {
                     print("\(error.userInfo)")
                 }
           
       }
    func validar (usuario: String, contrasena: String) -> Bool {

     guard let usuario = self.txtUsuario.text, usuario != "" else {
        self.basica(title: "Atención", message: "Complete el campo correo")
        return false }

     guard usuario.validarEmail else {
        self.basica(title: "Atención", message: "Verifique que el campo correo contenga los siguientes caracteres ejemplo@dominio.com")
        return false }
               
       guard let contraseña = self.txtContrasena.text, contraseña != "" else {
         self.basica(title: "Atención", message: "Complete el campo contraseña")
         return false }
               
       guard contraseña.count >= 8 else {
          self.basica(title: "Atención", message: "son 8 caracteres minimos en  la contraseña")
               return false }
       return true
    }

}

