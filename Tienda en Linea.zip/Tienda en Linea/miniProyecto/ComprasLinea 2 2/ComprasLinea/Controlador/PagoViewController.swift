//
//  PagoViewController.swift
//  ComprasLinea
//
//  Created by MAC on 12/22/19.
//  Copyright © 2019 MAC. All rights reserved.
//

import UIKit

class PagoViewController: UIViewController {
    
    //MARK: -IBOUTLETS
    @IBOutlet weak var txtNumTarjeta: UITextField!
    @IBOutlet weak var txtVigencia: UITextField!
    @IBOutlet weak var txtCVV: UITextField!
    @IBOutlet weak var txtPropietario: UITextField!
    
    //MARK: -PUBLIC VARIABLES
    var correo: String = ""
    var objProductosSeleccionados = [ProductoSeleccionado]()
    var total: Double = 0.0
    var date: String = "01/20"
    var dateFormatter = DateFormatter()
    var domicilio = ""
    var subtotal: String = ""
    var folio: String = ""
    
    //MARK: -LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboard()
    }
    
    //MARK: -IBACTIONS
    @IBAction func btnPagar(_ sender: UIButton) {
    guard let tarjeta = txtNumTarjeta.text, let vigencia = txtVigencia.text, let cvv = txtCVV.text, let propietario = txtPropietario.text else {return}
        guardarPago(tarjeta: Int(tarjeta) ?? 0, vigencia: vigencia, CVV: Int(cvv) ?? 0, propietario: propietario)
    }
    @IBAction func btnCancelar(_ sender: UIButton) {
      performSegue(withIdentifier: "productos", sender: nil)
           }
    
    //MARK: -NAVIGATIONS
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       let destination = segue.destination as! PorcesoPagoViewController
        destination.correo = correo
        destination.objProductosSeleccionados = objProductosSeleccionados
        destination.total = total
        destination.domicilio = domicilio
        destination.tarjeta = txtNumTarjeta.text ?? ""
        destination.subtotal = subtotal
        destination.folio = folio
    }
    
    //MARK: -FUNCTIONS
    func guardarPago(tarjeta: Int, vigencia: String, CVV: Int, propietario: String){
        if validaTarjeta (tarjeta: tarjeta, vigencia: vigencia, cvv: CVV, propietario: propietario) {
           let tarjeta: Tarjeta = Tarjeta(dic: ["correo": correo,"numeroTarjeta":tarjeta,"fechaDeVigenciaTarjeta": vigencia,"cvv": CVV,"nombreCompletoTitular": propietario])
            self.showActivityIndicatory(uiView: self.view)
        guardarTarjeta(correo: correo,tarjeta: tarjeta, completions: { success, message  in
                      print("message completions -> \(message)")
                        DispatchQueue.main.async {
                        self.hideActivityIndicator(uiView: self.view)
                        if success {
                            self.accion(title: "Usuario", message: message , actionButton: {
                            self.performSegue(withIdentifier: "historial", sender: nil)
                        })
                     } else {
                            DispatchQueue.main.async{
                             self.basica(title: "Atención", message: message)
                       }
                                            
                   }
            }
        })
        }else {
                DispatchQueue.main.async{
                self.basica(title: "Atención", message: "No se puede enviar los datos de la tarjeta")
          }
        }
    }

    func validaTarjeta (tarjeta: Int, vigencia: String, cvv: Int, propietario: String) -> Bool {

        dateFormatter.dateFormat = "MM/yy"
        let dateString = dateFormatter.date(from: date)
        print(dateFormatter.string(from: dateString!))
        
        guard let numtarjeta = self.txtNumTarjeta.text, String(numtarjeta) != "" else {
           self.basica(title: "Atención", message: "Complete el campo de numero de tarjeta")
          return false }
        guard numtarjeta.validarNumero else {
         self.basica(title: "Atención", message: "Error en el numero de tarjeta son puros numeros")
        return false }
        guard numtarjeta.count == 16 else {
            self.basica(title: "Atencion", message: "el numero de la Tarjeta tiene que ser de 16 digitos")
            return false}
        
        guard let vigencia = self.txtVigencia.text, vigencia != "" else {
            self.basica(title: "Atencion", message: "complete el campo de la vigencia")
            return false}
        
        guard vigencia != dateFormatter.string(from: dateString!) else {
            self.basica(title: "Atencion", message: "el campo vigencia no es correcto")
            return false}
        
        guard let cvv = self.txtCVV.text, String(cvv) != "" else{
            self.basica(title: "Atencion", message: "complete el campo CVV")
            return false
        }
        guard cvv.count == 3 else{
            self.basica(title: "Atencion", message: "El CVV tiene que ser de 3 digitos")
            return false
        }
        
        guard let propietario = self.txtPropietario.text, propietario != "" else {
            self.basica(title: "Atencion", message: "complete el campo del propietario")
            return false}
        
        guard propietario.validarTexto else{
            self.basica(title: "Atencion", message: "el nombre no es valido no contiene los caracteres requeridos")
            return false
        }
        
        return true
      }
}
