//
//  TableViewCellProducto.swift
//  ComprasLinea
//
//  Created by MAC on 12/19/19.
//  Copyright © 2019 MAC. All rights reserved.
//

import UIKit
import CoreData

//MARK: -PROTOCOL
protocol Celda {
    func agregar(producto: Product, lbl: UILabel)
}

class TableViewCellProducto: UITableViewCell {
    
    
    //MARK: -IBOUTLETS
    @IBOutlet weak var imgProducto: UIImageView!
    @IBOutlet weak var lblProducto: UILabel!
    @IBOutlet weak var lblStock: UILabel!
    @IBOutlet weak var lblPrecio: UILabel!
    @IBOutlet weak var lblCantidad: UILabel!
    @IBOutlet weak var StpContador: UIStepper!
    @IBOutlet weak var btnAgregar: UIButton!
    
    //MARK: -PUBLIC VARIABLES
    var lista:[NSManagedObject] = []
    var delegate: Celda?
    var producto: Product?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    //MARK: -IBACTIONS
    @IBAction func btnAgregarCarrito(_ sender: UIButton) {
            delegate?.agregar(producto: producto!, lbl: lblCantidad!)
        }
    @IBAction func stpContar(_ sender: UIStepper) {
      var number = 0
        number = Int(sender.value)
        self.lblCantidad.text = String(number)
        StpContador.minimumValue = 1.0
        StpContador.maximumValue = Double(lblStock.text!)!
    }
        override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    /*func guardarProducto(producto: String,precio: Float?,cantidad: Int16?) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let managedContext = appDelegate.persistentContainer.viewContext
         let entity = NSEntityDescription.entity(forEntityName: "Compra", in: managedContext)!
         let managedObject = NSManagedObject(entity: entity, insertInto: managedContext)
         print(producto)
         managedObject.setValue(producto, forKeyPath: "nombreProducto")
         managedObject.setValue(precio, forKeyPath: "precio")
         managedObject.setValue(cantidad, forKeyPath: "cantidad")
         do{
             try managedContext.save()
            lista.append(managedObject)
         }catch let error as NSError {
             print("\(error.userInfo)")
     }
    }*/
}
