//
//  TableViewCellHistorial.swift
//  ComprasLinea
//
//  Created by Natanael Cruz Mota on 19/01/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit
 
class TableViewCellHistorial: UITableViewCell {
    @IBOutlet weak var lblNombreProducto: UILabel!
    @IBOutlet weak var lblCantidad: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
       // Configure the view for the selected state
    }

}
