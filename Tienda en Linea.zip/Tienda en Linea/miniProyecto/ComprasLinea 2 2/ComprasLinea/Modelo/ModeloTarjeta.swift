//
//  ModeloTarjeta.swift
//  ComprasLinea
//
//  Created by Natanael Cruz Mota on 14/01/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import Foundation

struct Tarjeta: Decodable {
   
    var numTarjeta: Int
    var vigencia: String
    var cvv: Int
    var nombrePropietario: String

 init(dic: [String: Any]) {
    self.numTarjeta = dic["numeroTarjeta"] as? Int ?? 0
    self.vigencia = dic["fechaDeVigenciaTarjeta"] as? String ?? ""
    self.cvv = dic["cvv"] as? Int ?? 0
    self.nombrePropietario = dic["nombreCompletoTitular"] as? String ?? ""
   
    }
  init(iTarjeta: Int, strVigencia: String, iCvv: Int, strPropietario: String) {
    self.numTarjeta = iTarjeta
    self.vigencia =  strVigencia
    self.cvv = iCvv
    self.nombrePropietario = strPropietario
    }
    
}
